
clc
clear
close all
pkg load signal


 % EXERCITII
##
##Exercitiul1
## y[n] + 0,13y[n −1] + 0,52y[n − 2] + 0,3y[n − 3] = 0,16x[n] − 0,48x[n −1] + 0,48x[n − 2] − 0,16x[n − 3]
##

 b = [1, 0.13, 0.52,0.3];
 a = [0.16, -0.48, 0.48, -0.16];
 [H,W] = freqz(b,a);
 x1 = impuls(0, 40, 0);
 x2 = treapta(0, 40, 0);
 n = 0:40;

 ##Subpunctul a

 x3 = [zeros(1,41)];
 y3 = filter([0.16, -0.48, 0.48, -0.16], 1, x3);
 figure(1);
 subplot(3,1,1); stem(n,x3); xlabel('n'); ylabel('x[n]');
 subplot(3,1,2); stem(n,[0.16, -0.48, 0.48, -0.16]); xlabel('n'); ylabel('h[n]');
 subplot(3,1,3); stem(n,y3); xlabel('n'); ylabel('y[n]');

 x4 = heaviside(n);
 y4 = filter([0.16, -0.48, 0.48, -0.16], 1, x4);
 figure(2);
 subplot(3,1,1); stem(n,x4); xlabel('n'); ylabel('x[n]');
 subplot(3,1,2); stem(n,[0.16, -0.48, 0.48, -0.16]); xlabel('n'); ylabel('h[n]');
 subplot(3,1,3); stem(n,y4); xlabel('n'); ylabel('y[n]');


 %Subpunctul b
 % semnalul de intrare x1
 figure(2);
 subplot(3, 1, 1);
 stem(n, x1);
 title('Semnalul de intrare x1');
 xlabel('n');
 ylabel('Amplitudine');

 % răspunsul în frecvență
 subplot(3, 1, 2);
 plot(W, abs(H));
 title('Răspunsul în frecvență H1');
 xlabel('Frecvență');
 ylabel('Amplitudine');

 % semnalul de ieșire
 subplot(3, 1, 3);
 y1 = filter(b, a, x1);
 stem(n, y1);
 title('Semnalul de ieșire y1');
 xlabel('n');
 ylabel('Amplitudine');

 % semnalul de intrare x2
 figure(3);
 subplot(3, 1, 1);
 stem(n, x2);
 title('Semnalul de intrare x2');
 xlabel('n');
 ylabel('Amplitudine');

 % răspunsul în frecvență
 subplot(3, 1, 2);
 plot(W, abs(H));
 title('Răspunsul în frecvență H2');
 xlabel('Frecvență');
 ylabel('Amplitudine');

 % semnalul de ieșire
 subplot(3, 1, 3);
 y2 = filter(b, a, x2);
 stem(n, y1);
 title('Semnalul de ieșire y2');
 xlabel('n');
 ylabel('Amplitudine');

 %Subpunctul c
 zplane(b,a);
 poly(a);
 poly(b);










##EXERCITIUL 2


H(z)= 1/(1-0.77z%%^-1 + 0.44z^-3)

 b = 1;
 a = [1, -0.77, 0, 0.44];
 n = 0:40;
 [H,W] = freqz(b,a);
 x1 = impuls(0, 40, 0);
 x2 = treapta(0, 40, 0);



 ##Subpunctul a

 x5 = [zeros(1,41)];
 y5 = filter([1, -0.77, 0, 0.44], 1, x5);
 figure(1);
 subplot(3,1,1); stem(n,x5); xlabel('n'); ylabel('x[n]');
 subplot(3,1,2); stem(n,[1, -0.77, 0, 0.44]); xlabel('n'); ylabel('h[n]');
 subplot(3,1,3); stem(n,y5); xlabel('n'); ylabel('y[n]');

 x6 = heaviside(n);
 y6 = filter([1, -0.77, 0, 0.44], 1, x6);
 figure(2);
 subplot(3,1,1); stem(n,x6); xlabel('n'); ylabel('x[n]');
 subplot(3,1,2); stem(n,[1, -0.77, 0, 0.44]); xlabel('n'); ylabel('h[n]');
 subplot(3,1,3); stem(n,y6); xlabel('n'); ylabel('y[n]');








 ##Subpunctul b

 % semnalul de intrare x1
 figure(2);
 subplot(3, 1, 1);
 stem(n, x1);
 title('Semnalul de intrare x1');
 xlabel('n');
 ylabel('Amplitudine');

 % răspunsul în frecvență
 subplot(3, 1, 2);
 plot(W, abs(H));
 title('Răspunsul în frecvență H1');
 xlabel('Frecvență');
 ylabel('Amplitudine');

 % semnalul de ieșire
 subplot(3, 1, 3);
 y1 = filter(b, a, x1);
 stem(n, y1);
 title('Semnalul de ieșire y1');
 xlabel('n');
 ylabel('Amplitudine');

 % semnalul de intrare x2
 figure(3);
 subplot(3, 1, 1);
 stem(n, x2);
 title('Semnalul de intrare x2');
 xlabel('n');
 ylabel('Amplitudine');

 % răspunsul în frecvență
 subplot(3, 1, 2);
 plot(W, abs(H));
 title('Răspunsul în frecvență H2');
 xlabel('Frecvență');
 ylabel('Amplitudine');

 % semnalul de ieșire
 subplot(3, 1, 3);
 y2 = filter(b, a, x2);
 stem(n, y1);
 title('Semnalul de ieșire y2');
 xlabel('n');
 ylabel('Amplitudine');









##Subpunctul c
 figure, zplane(b,a);
 poly(a);
 poly(b);



